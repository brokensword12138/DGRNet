import cv2
import numpy as np
import torchvision.transforms as transforms
from PIL import Image
import yaml
import os
import matplotlib.pyplot as plt
from os.path import join
import torch
import torch.nn.functional as F
import glob

from model.DeepfakeMae1grad import RFFRL
# 读取图像
image_path = '/mnt/data/prediction_17.png'
image = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)

# 确保图像是 NumPy 数组
if not isinstance(image, np.ndarray):
    raise TypeError("读取的图像不是有效的 NumPy 数组")

# 检查图像数据类型，并转换为 float32（可选）
if image.dtype != np.uint8:
    image = image.astype(np.uint8)

# 设置阈值
threshold_value = 128  # 可根据需要调整阈值
_, binary_image = cv2.threshold(image, threshold_value, 255, cv2.THRESH_BINARY)

# 显示原始图像和二值化后的图像
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.title('Original Image')
plt.imshow(image, cmap='gray')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.title('Binary Image')
plt.imshow(binary_image, cmap='gray')
plt.axis('off')

plt.show()