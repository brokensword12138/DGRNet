import cv2
import numpy as np
import torchvision.transforms as transforms
from PIL import Image
import yaml
import os
import matplotlib.pyplot as plt
from os.path import join
#from model.LVNet import ViTAdapter
from model.DeepfakeMae1grad import RFFRL
from utils.utils import *
import torch.nn.functional as F
import math
import glob
from pytorch_grad_cam import GradCAM

#os.environ["CUDA_VISIBLE_DEVICES"] = '1'
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def show_with_grad_cam(model, path_img, path_img1, out_img1):

    img_raw = Image.open(path_img).convert('RGB')
    img_raw = transforms.ToTensor()(img_raw).to(device)
    img_raw = F.interpolate(img_raw.unsqueeze(0), size=(224, 224), mode='bilinear', align_corners=False).squeeze(0)
    _, H, W = img_raw.size()

    features_map1 = []
    grads1 = []

    def get_feature_map1(module, ip, op):
        features_map1.append(op.cpu().data.numpy())

    def get_grad1(module, grad_in, grad_out):
        grads1.append(grad_out[0].cpu().detach().data.numpy())

    model.dd.register_forward_hook(get_feature_map1)
    model.dd.register_backward_hook(get_grad1)

    data = img_raw.unsqueeze(0)  # [1, 3, 224, 224]
    #print("data",data.size())
    # Y_pre, recon_x1, recon_x2, iea, output = model(data)
    output = model(data)
    
    output = output.squeeze()#[2]
    #print("output",output.size())
    idx = output.cpu().sort(descending=True)[1].data.numpy()[0]
    model.zero_grad()
    loss = output[idx]
    loss.backward()
    
    fm1 = features_map1[0][0]
    
    grad1 = grads1[0][0]
    weight1 = np.mean(grad1.reshape([grad1.shape[0], -1]), axis=1)
    #print("fm1",fm1.shape)
    #print("grad1",grad1.shape)
    #print("weight1",grad1.shape)
    #fm1 (1536,)
    #grad1 (1536,)
    #weight1 (1536,)
    #channel, h, w = fm1.shape
    #fm1 = fm1.reshape(1, 1, 1536)
    #fm1 = fm1.reshape(1,728,2)
    #exit(0)
    #cam1 = weight1.dot(fm1.reshape(channel, h * w)).reshape((h, w))
    cam1 = weight1.dot(fm1)
    #print(cam1)
    #exit(0)
    img1 = cv2.imread(path_img1, 1)
    img1 = cv2.resize(img1, (224, 224))
    #print(img1.shape)

    cam_img1 = (cam1 - cam1.min()) / (cam1.max() - cam1.min())
    cam_img1 = np.uint8(255 * cam_img1)
    #print("cam_img1",cam_img1.shape)
    #exit(0)
    cam_img1 = cv2.resize(np.array(cam_img1), (img1.shape[1], img1.shape[0]))
    #print(cam_img1.shape)
    heatmap1 = cv2.applyColorMap(cam_img1, cv2.COLORMAP_JET)

    img = cv2.imread(path_img, 1)
    # img = cv2.resize(img, (224, 224))
    #print(img.shape)

    cam_img1 = 0.5 * heatmap1 + 0.5 * img1
    #print(out_img1, cam_img1.shape)
    cv2.imwrite(out_img1, cam_img1)


if __name__ == '__main__':

    with open("config/FF++.yml") as config_file:
        config = yaml.load(config_file, Loader=yaml.FullLoader)

    #model = ViTAdapter(split='test')
    model = RFFRL()
    model = model.cuda()
    model.eval()

    state_dict = torch.load(config['test']['ckt_path'], map_location='cpu')
    model.load_state_dict(cleanup_state_dict(state_dict['state_dict']), strict=False)

    # image = '/home/jiayixin/LVN-JIA/grad_cam/FS-Input/73.jpg'
    # image1 = '/home/jiayixin/LVN-JIA/grad_cam/FS-Input/73.jpg'
    #root_dir = '/home/jiayixin/Experiment/Gai10-MAE-vit-input/grad_cam/TSNE-Output/'
    root_dir = '/root/autodl-tmp/TSNE-Output'
    if not os.path.exists(root_dir):
        os.mkdir(root_dir)

    #directory = '/home/jiayixin/Experiment/Gai10-MAE-vit-input/grad_cam/TSNE-Input/'
    directory = '/root/autodl-tmp/TSNE-Input'
    image_files = [file for file in glob.glob(os.path.join(directory, '*.jpg'))]
    for image_file in image_files:
        show_with_grad_cam(model, image_file, image_file, join(root_dir, '{}'.format(image_file.split('/')[-1])))
        


    # show_with_grad_cam(model, image, image1, join(root_dir, '{}'.format(image.split('/')[-1])))