import cv2
import numpy as np
import torchvision.transforms as transforms
from PIL import Image
import yaml
import os
import matplotlib.pyplot as plt
from os.path import join
import torch
import torch.nn.functional as F
import glob
from model.DeepfakeMae1grad import RFFRL

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

def cleanup_state_dict(state_dict):
    """Removes 'module.' prefix from state_dict keys."""
    new_state_dict = {}
    for k, v in state_dict.items():
        if k.startswith('module.'):
            new_state_dict[k[7:]] = v
        else:
            new_state_dict[k] = v
    return new_state_dict

def show_with_grad_cam(model, path_img, path_img1, out_img1):
    img_raw = Image.open(path_img).convert('RGB')
    img_raw = transforms.ToTensor()(img_raw).to(device)
    img_raw = F.interpolate(img_raw.unsqueeze(0), size=(224, 224), mode='bilinear', align_corners=False).squeeze(0)
    _, H, W = img_raw.size()

    features_map1 = []
    grads1 = []

    def get_feature_map1(module, ip, op):
        features_map1.append(op.cpu().data.numpy())

    def get_grad1(module, grad_in, grad_out):
        grads1.append(grad_out[0].cpu().detach().data.numpy())

    model.dd.backbone_1.blocks[-1].norm1.register_forward_hook(get_feature_map1)
    model.dd.backbone_1.blocks[-1].norm1.register_backward_hook(get_grad1)

    data = img_raw.unsqueeze(0)  # [1, 3, 224, 224]
    output = model(data)

    output = output.squeeze()
    idx = output.cpu().sort(descending=True)[1].data.numpy()[0]
    model.zero_grad()
    loss = output[idx]
    loss.backward()

    fm1 = features_map1[0][0]  # (197, 768)
    grad1 = grads1[0][0]  # (197, 768)
    weight1 = np.mean(grad1, axis=0)  # (768,)
    
    # Remove the class token and reshape the feature map
    fm1 = fm1[1:]  # (196, 768)
    h = w = int(np.sqrt(fm1.shape[0]))  # assuming the patches form a square
    fm1 = fm1.reshape((h, w, -1))  # (14, 14, 768)

    cam1 = np.dot(fm1, weight1).reshape((h, w))

    img1 = cv2.imread(path_img1, 1)
    cam_img1 = (cam1 - cam1.min()) / (cam1.max() - cam1.min())
    cam_img1 = np.uint8(255 * cam_img1)
    cam_img1 = cv2.resize(cam_img1, (img1.shape[1], img1.shape[0]))
    heatmap1 = cv2.applyColorMap(cam_img1, cv2.COLORMAP_JET)

    img = cv2.imread(path_img, 1)
    cam_img1 = 0.5 * heatmap1 + 0.5 * img1
    cv2.imwrite(out_img1, cam_img1)

if __name__ == '__main__':
    with open("config/FF++.yml") as config_file:
        config = yaml.load(config_file, Loader=yaml.FullLoader)

    model = RFFRL().to(device)
    model.eval()

    state_dict = torch.load(config['test']['ckt_path'], map_location='cpu')
    model.load_state_dict(cleanup_state_dict(state_dict['state_dict']), strict=False)

    root_dir = '/root/autodl-tmp/TSNE-Output'
    if not os.path.exists(root_dir):
        os.mkdir(root_dir)

    directory = '/root/autodl-tmp/TSNE-Input'
    image_files = [file for file in glob.glob(os.path.join(directory, '*.jpg'))]
    for image_file in image_files:
        show_with_grad_cam(model, image_file, image_file, join(root_dir, '{}'.format(image_file.split('/')[-1])))
