import os                                       #mae
import timm.optim.optim_factory as optim_factory
import wandb
import argparse
import time
import random
import shutil
import warnings
import json
import yaml

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import torch.distributed as dist
import torch.multiprocessing as mp
import numpy as np
from torch.optim import lr_scheduler
from sklearn import metrics
from torch.autograd import Variable

from datasets.ff_all import FaceForensics
from datasets.factory import create_data_transforms
#from model.LVNet import Two_Stream_Net
from model.DeepfakeMae1TSNE import RFFRL
from loss.seg_loss import *
from utils.utils import *
from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

torch.autograd.set_detect_anomaly(True)

def main():
    #### setup options of three networks
    parser = argparse.ArgumentParser()

    parser.add_argument("--opt", default='./config/FF++.yml', type=str, help="Path to option YMAL file.")
    
    parser.add_argument('--world_size', default=1, type=int,
                    help='number of nodes for distributed training')
    parser.add_argument('--rank', default=-1, type=int,
                        help='node rank for distributed training')
    parser.add_argument('--dist_backend', default='nccl', type=str,
                        help='distributed backend')
    parser.add_argument('--local_rank', default=-1, type=int)
    parser.add_argument('--dist-url', default='env://', type=str,
                        help='url used to set up distributed training')
    parser.add_argument('--dist-backend', default='nccl', type=str,
                        help='distributed backend')
    parser.add_argument('--gpu', default=None, type=int,
                    help='GPU id to use.')
    parser.add_argument('--device', default=0, type=int,
                    help='GPU id to use.')

    parser.add_argument('--mixup', action="store_false",
                    help='using mixup augmentation.')
    
    parser.set_defaults(bottleneck=True)
    parser.set_defaults(verbose=True)

    args = parser.parse_args()

    opt = yaml.safe_load(open(args.opt, 'r'))
    seed = opt["train"]["manual_seed"]
        

    if seed is not None:
        # random.seed(args.seed)
        if args.gpu is None:
            torch.cuda.manual_seed_all(seed)
        else:
            torch.cuda.manual_seed(seed)
        cudnn.deterministic = True
        warnings.warn('You have chosen to seed training. '
                      'This will turn on the CUDNN deterministic setting, '
                      'which can slow down your training considerably! '
                      'You may see unexpected behavior when restarting '
                      'from checkpoints.')

    if args.gpu is not None:
        warnings.warn('You have chosen a specific GPU. This will completely '
                      'disable data parallelism.')
    else:  
        if args.dist_url == "env://" and args.world_size == -1:
            args.world_size = int(os.environ["WORLD_SIZE"])

    args.distributed = args.world_size > 1

    ngpus_per_node = torch.cuda.device_count()

    main_worker(args.gpu, ngpus_per_node, args, opt)
        

def main_worker(gpu, ngpus_per_node, args, opt):

    args.gpu = gpu

    config = wandb.config
    config = vars(args)
    
    if args.gpu is not None:
        print("Use GPU: {} for training".format(args.gpu))
        torch.cuda.set_device(args.gpu)
        args.device = torch.device(args.gpu)

    elif args.distributed:
        if args.dist_url == "env://" and args.rank == -1:
            args.rank = int(os.environ["RANK"])
        args.local_rank = int(os.environ['LOCAL_RANK'])
        torch.cuda.set_device(args.local_rank)
        args.device = torch.device(args.local_rank)

        dist.init_process_group(backend=args.dist_backend, init_method=args.dist_url, world_size=args.world_size, rank=args.rank)
    else:
        pass
    
    # # wandb 
    # if args.gpu is not None or args.rank == 0:
    #     wandb.init(project='Face-Forgery-Detection', group='20230702', name='two-stream-xception', config=config)

    # create model
    print(f"Creating model: {opt['model']['baseline']}")
    model = RFFRL()
    model.to(args.device)

    if not opt['train']['resume'] == None:
        from_pretrained(model, opt)

    if args.distributed:
        model = torch.nn.parallel.DistributedDataParallel(model, device_ids=[args.local_rank],
                                            output_device=args.local_rank, find_unused_parameters=True)
        param_groups = optim_factory.add_weight_decay(model.module, opt['train']['weight_decay'])
    else:
        param_groups = optim_factory.add_weight_decay(model, opt['train']['weight_decay'])

    # define loss function (criterion) and optimizer
    criterion = nn.CrossEntropyLoss().to(args.device)#微调阶段暂时只使用交叉熵损失做二分类
    segLoss = FSCELoss().to(args.device)#有了定位分支之后，加入定位损失函数

    optimizer = torch.optim.Adam(param_groups, lr=opt['train']['lr'], betas=(0.9, 0.999))
    scheduler = lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)

    cudnn.benchmark = True

    # Data loading code
    #微调阶段，数据加载同时加载真实和伪造的图像，所以读取数据这一块不用动
    all_transform = create_data_transforms(opt)
    train_data = FaceForensics(opt, split='train', transforms=all_transform)
    val_data = FaceForensics(opt, split='val', transforms=all_transform)

    if args.distributed:
        train_sampler = torch.utils.data.distributed.DistributedSampler(train_data, rank=args.local_rank)
        val_sampler = torch.utils.data.distributed.DistributedSampler(val_data, rank=args.local_rank)

    else:
        train_sampler = None
        val_sampler = None

    train_loader = torch.utils.data.DataLoader(
        train_data, batch_size=opt['datasets']['train']['batch_size'], shuffle=(train_sampler is None),
        num_workers=opt['datasets']['n_workers'], sampler=train_sampler, drop_last=True)
    val_loader = torch.utils.data.DataLoader(
        val_data, batch_size=opt['datasets']['train']['batch_size'], shuffle=False,
        num_workers=opt['datasets']['n_workers'], sampler=val_sampler, drop_last=False)

    if (args.gpu is not None or args.local_rank == 0) and opt['train']['resume'] == None: 
        save_path = opt['train']['save_path']
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        var_dict = vars(args)
        var_dict['optimizer'] = str(optimizer.__class__.__name__)
        var_dict['device'] = str(args.device)
        json_str = json.dumps(var_dict)
        with open(os.path.join(save_path, 'config.json'), 'w') as json_file:
            json_file.write(json_str)

    best = 0.0

    for epoch in range(opt['train']['start_epoch'], opt['train']['epoch']):
        if args.distributed:
            train_sampler.set_epoch(epoch)

        # train for one epoch
        #训练损失只用交叉熵损失，暂时去掉定位损失
        train_acc, train_loss, train_celoss, train_segloss = train(train_loader, model, criterion, 
             segLoss, optimizer, epoch, args, opt)
        test_acc, test_loss, test_auc = validate(val_loader, model, criterion, epoch, args, opt)
        scheduler.step()

        is_best = test_auc > best
        best = max(test_auc, best)

        '''if epoch % 5 == 0:
            save_checkpoint(state={
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'optimizer' : optimizer.state_dict(),
            }, is_best=is_best, epoch=epoch)#删掉file参数，因为根本找不到该参数的位置
        
            for param_group in optimizer.param_groups:
                cur_lr = param_group['lr']

            log_info = {
                "train_acc": train_acc,
                "train_loss": train_loss,
                'train_celoss': train_celoss,
                'train_segloss': train_segloss,
                "test_acc": test_acc,
                "test_loss": test_loss,
                'test_auc': test_auc,
                'learning_rate': cur_lr
            }
            # wandb.log(log_info)'''
        if epoch < 20:
            save_checkpoint(state={
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'optimizer' : optimizer.state_dict(),
            }, is_best=is_best, epoch=epoch)#删掉file参数，因为根本找不到该参数的位置
        
            for param_group in optimizer.param_groups:
                cur_lr = param_group['lr']

            log_info = {
                "train_acc": train_acc,
                "train_loss": train_loss,
                'train_celoss': train_celoss,
                'train_segloss': train_segloss,
                "test_acc": test_acc,
                "test_loss": test_loss,
                'test_auc': test_auc,
                'learning_rate': cur_lr
            }
            # wandb.log(log_info)
        if epoch > 20 and epoch % 5 == 0:
            save_checkpoint(state={
                'epoch': epoch + 1,
                'state_dict': model.state_dict(),
                'optimizer' : optimizer.state_dict(),
            }, is_best=is_best, epoch=epoch)#删掉file参数，因为根本找不到该参数的位置
        
            for param_group in optimizer.param_groups:
                cur_lr = param_group['lr']

            log_info = {
                "train_acc": train_acc,
                "train_loss": train_loss,
                'train_celoss': train_celoss,
                'train_segloss': train_segloss,
                "test_acc": test_acc,
                "test_loss": test_loss,
                'test_auc': test_auc,
                'learning_rate': cur_lr
            }
         # 生成并保存TSNE散点图
        
        # wandb.log(log_info)
            

'''def mixup_data(x, y, m, alpha=1.0, device='cpu'):
    Returns mixed inputs, pairs of targets, and lambda
    rd = np.random.rand(1)

    if rd > 0.5:
        lam = np.random.beta(alpha, alpha)
    else:
        lam = 1

    batch_size = x.size()[0]
    index = torch.randperm(batch_size).to(device)

    mixed_x = lam * x + (1 - lam) * x[index, :]
    y_a, y_b = y, y[index]
    m_a, m_b = m, m[index]

    return mixed_x, y_a, y_b, m_a, m_b, lam


def mixup_criterion(criterion, pred, y_a, y_b, lam):
    return lam * criterion(pred, y_a) + (1 - lam) * criterion(pred, y_b)
def mixup_segLoss(segLoss, psegs, m_a, m_b, lam):
    return lam * segLoss(psegs, m_a) + (1 - lam) * segLoss(psegs, m_b)'''


        
def train(train_loader, model, criterion, segLoss, optimizer, epoch, args, opt):
    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    losses_ce = AverageMeter('Loss_ce', ':.5f')
    losses_seg = AverageMeter('Loss_seg', ':.5f')
    losses = AverageMeter('Loss', ':.5f')
    acc = AverageMeter('Acc@1', ':6.2f')
    # top5 = AverageMeter('Acc@5', ':6.2f')         
    progress = ProgressMeter(
        len(train_loader),
        [batch_time, data_time, losses_ce, losses_seg, losses, acc],
        prefix="Epoch: [{}]".format(epoch))

    # switch to train mode
    model.train()
    
    
    
    end = time.time()
    #散点图
    
    all_images = []
    all_labels = []
    bs = 0
    
    for i, (images, labels, masks) in enumerate(train_loader):
        # measure data loading time
        data_time.update(time.time() - end)
        
        #print(labels.is_cuda)
        #print(args.device)
        images = images.to(args.device)
        labels = labels.to(args.device)
        masks = masks.to(args.device).float()
        #print(labels.is_cuda)

        masks[masks > 0] = 1.0
        # forward
        '''if args.mixup:
            inputs, labels_a, labels_b, masks_a, masks_b, lam = mixup_data(images, 
                    labels, masks, device=args.device)
            inputs, labels_a, labels_b, masks_a, masks_b = map(Variable, (inputs, labels_a, labels_b,
                                                        masks_a, masks_b))

            preds, psegs, [masks_a, masks_b] = model(inputs, [masks_a, masks_b])

            # compute output
            loss_ce = mixup_criterion(criterion, preds, labels_a, labels_b, lam)
            loss_seg = mixup_segLoss(segLoss, psegs, masks_a, masks_b, lam)'''
            
        #else:
        preds, psegs, masks, features_flattened = model(images,masks)
       
        #exit(0)
        
        bs, num_features = features_flattened.size()
        
        loss_ce = criterion(preds, labels)
        loss_seg = segLoss(psegs, masks)
        
        for j in range(bs):
            if len(all_images) < 1000:
                x = features_flattened[j]
                all_images.append(x)
            if len(all_labels) < 1000:
                y = labels[j]
                all_labels.append(y)
                
        # measure accuracy and record loss
        loss = loss_ce + loss_seg
        acc1 = accuracy(preds, labels, topk=(1,))[0]

        losses.update(loss.item(), images.size(0))
        losses_ce.update(loss_ce.item(), images.size(0))
        losses_seg.update(loss_seg.item(), images.size(0))
        acc.update(acc1, images.size(0))
        
        # compute gradient and do SGD step
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if  i % 20 == 0:
            progress.display(i)
    
    # TSNE figures
    print(len(all_images))
    print(len(all_labels))
    colors = plt.cm.rainbow(np.linspace(0, 1, 2))
    tsne = TSNE(n_components=2, random_state=42)
    image = torch.stack(all_images, dim=0).detach().cpu().numpy()
    features_flattened = image.reshape(len(all_images), -1)
    embedded_features = tsne.fit_transform(features_flattened)
    label = torch.stack(all_labels, dim=0).detach().cpu().numpy()
    # embedded_features = tsne.fit_transform(torch.stack(all_images, dim=0).detach().cpu().numpy())
    plt.figure(figsize=(10, 10))
    for i in range(0, 2):
        indices = label.squeeze() == i
        # 获取对应标签的特征
        x = embedded_features[indices, 0]
        y = embedded_features[indices, 1]
        # 绘制散点图
        plt.axis('off')
        plt.scatter(x, y, color=colors[i], label=f'Label {i}')
    plt.savefig('/root/autodl-tmp/input/MAE_tsne_epoch_{}.png'.format(epoch))
    return acc.avg, losses.avg, losses_ce.avg, losses_seg.avg

@torch.no_grad()
def validate(val_loader, model, criterion, epoch, args, opt):
    model.eval()

    batch_time = AverageMeter('Time', ':6.3f')
    data_time = AverageMeter('Data', ':6.3f')
    losses = AverageMeter('Loss', ':.4e')
    acc = AverageMeter('Acc@1', ':6.2f')

    progress = ProgressMeter(
        len(val_loader),
        [batch_time, data_time, losses, acc],
        prefix="Epoch: [{}]".format(epoch))

    end = time.time()
    y_trues = []
    y_preds = []
    for i, (images, labels, masks) in enumerate(val_loader):
        data_time.update(time.time() - end)
        
        images = images.to(args.device)
        labels = labels.to(args.device)
        masks = masks.to(args.device).float()

        masks[masks > 0] = 1.0
        # forward
        preds, psegs, masks,features_flattened = model(images, masks)
        
        
        # measure accuracy and record loss
        loss = criterion(preds, labels)
        acc1 = accuracy(preds, labels, topk=(1,))[0]

        losses.update(loss.item(), images.size(0))
        acc.update(acc1, images.size(0))
        # top5.update(acc5, images.size(0))

        y_trues.extend(labels.cpu().numpy())
        prob = 1 - torch.softmax(preds, dim=1)[:, 0].cpu().numpy()
        y_preds.extend(prob)
        # measure elapsed time
        batch_time.update(time.time() - end)
        end = time.time()

        if  i % 20 == 0:
            progress.display(i)
            
    fpr, tpr, thresholds = metrics.roc_curve(y_trues, y_preds, pos_label=1)
    auc = metrics.auc(fpr, tpr)

    #print(f' * Acc@1 {acc.avg:.3f}, auc {auc:.3f}')
    print(f' * Acc@1 {acc.avg:.4f}, auc {auc:.4f}')
    return acc.avg, losses.avg, auc


def save_checkpoint(state, is_best, epoch, file='/root/autodl-tmp/input'):
    # if os.path.exists(filename):
    #     os.mkdir()
    filename = os.path.join(file, 'checkpoint-{:02d}.pth.tar'.format(epoch))
    torch.save(state, filename)
    if is_best:
        shutil.copyfile(filename, os.path.join(file, 'model_best.pth.tar'))


def from_pretrained(model, opt):
    state_dict = torch.load(opt['train']['resume'], map_location='cpu')
    model.load_state_dict(cleanup_state_dict(state_dict['state_dict']), strict=False)

    opt['train']['lr'] = state_dict['optimizer']['param_groups'][0]['lr']
    opt['train']['start_epoch'] = state_dict['epoch']



    
if __name__ == '__main__':
    main()
