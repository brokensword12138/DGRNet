import os
import random
import cv2
import numpy as np

import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image


class FaceForensics(Dataset):
    def __init__(self,
                opt,
                split = 'test',
                downsample = 1,
                transforms=None,
                method=None,
                balance=False
                ):
        """
        Args:
            data_root (str): Root for images.
            transform (type, optional): Data transform. Defaults to None.
            downsample (int, optional): Defaults to 10, downsample to each video.
            balance (bool, optional): Whether balance the fake and real image. Defaults to True.
            method (str): a special forgery method. If none, data for four method are used.
        """

        self.data_root = opt['datasets']['root']
        self.split = split #test
        self.transforms = transforms 
        self.downsample = opt['datasets']['train']['downsample'] if self.split == 'train' else 1

        self.balance = opt['datasets'][split]['balance']  #False
        self.method = opt['datasets'][split]['method']   #~

        self.items = self._load_items()
    
        print(f'wilddeepfake(test): Total number of data: {len(self.items)}')

    def _load_items(self):
        items = []
        root = "/root/autodl-tmp/Wilddeepfake"
        
        real_images = torch.load(os.path.join(self.data_root,  "real.pickle"))
        fake_images = torch.load(os.path.join(self.data_root,  "fake.pickle"))
        #print(real_images)   
        #exit(0)
        for i in range(0,len(real_images),5):
            #print(line)                
            label = int(1)                               
            image_path = os.path.join(self.data_root, "real_test", real_images[i])
            items.append({
                    'image_path': image_path,
                    'label': int(label)
                })
            '''for i in range(0, len(imgs), self.downsample):
                image_path = os.path.join(video_path, imgs[i])
                items.append({
                    'image_path': image_path,
                    'label': int(label)
                })'''
        #print(items)
        #print("real itme")
        #print(len(items))
        
        
        for i in range(0,len(fake_images),5):
            #print(line)                
            label = int(0)                               
            image_path = os.path.join(self.data_root, "fake_test", fake_images[i])            
            items.append({
                    'image_path': image_path,
                    'label': int(label)
                })       
        #print(items)
        #exit(0)
        #print(len(items))
        #exit(0)
        return items

    def __getitem__(self, index):
        item = self.items[index]
        label = item['label']
        #print(item['image_path'])
        image = cv2.cvtColor(cv2.imread(item['image_path']), cv2.COLOR_BGR2RGB)
        image = self.transforms[self.split](image=image)['image']

        return image, label, image

    def __len__(self):
        return len(self.items)

    