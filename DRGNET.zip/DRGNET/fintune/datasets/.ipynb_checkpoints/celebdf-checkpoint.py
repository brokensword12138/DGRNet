import os
import random
import cv2
import numpy as np

import torch
from torch.utils.data import Dataset, DataLoader
from PIL import Image


class FaceForensics(Dataset):
    def __init__(self,
                opt,
                split = 'test',
                downsample = 1,
                transforms=None,
                method=None,
                balance=False
                ):
        """
        Args:
            data_root (str): Root for images.
            transform (type, optional): Data transform. Defaults to None.
            downsample (int, optional): Defaults to 10, downsample to each video.
            balance (bool, optional): Whether balance the fake and real image. Defaults to True.
            method (str): a special forgery method. If none, data for four method are used.
        """

        self.data_root = opt['datasets']['root'] #'/root/autodl-tmp/celeb_df/List_of_testing_videos.txt'
        self.split = split #test
        self.transforms = transforms 
        self.downsample = opt['datasets']['train']['downsample'] if self.split == 'train' else 1

        self.balance = opt['datasets'][split]['balance']  #False
        self.method = opt['datasets'][split]['method']   #~

        self.items = self._load_items()
    
        print(f'celebdf(test): Total number of data: {len(self.items)}')

    def _load_items(self):
        items = []
        root = "/root/autodl-tmp/celeb_df"
        with open(self.data_root, 'r') as f:
            lines = f.readlines()  #1 Celeb-real/id1_0007.mp4
            #print(lines)
            for line in lines:
                #print(line)                
                label, video_path = line[:-1].split(' ')                
                #print(label)  
                #print(video_path)  #Celeb-real/id1_0007.mp4  此处很奇怪 读取测试数据集的txt文件时读取不到最后一行内容的最后一个字符 故而在448行最后一行加入了一个x
                #exit(0)                                            #上述问题解决 因为448行后没有449行 导致没有换行符 读取漏掉最后一个字符
                #exit(0)autodl-tmp/celeb_df/Celeb-real
                
                video_path = os.path.join(root,video_path)
                #print(video_path)  #/root/autodl-tmp/celeb_df/Celeb-real/id1_0007.mp4
                imgs = os.listdir(video_path)
                #print(imgs) ['0000.png', '0001.png', '0002.png', '0003.png',...,'0029.png']
                
                for i in range(0, len(imgs), self.downsample):#三个参数 分别是起始 终止与步长
                    image_path = os.path.join(video_path, imgs[i])
                    items.append({
                        'image_path': image_path,
                        'label': int(label)
                    })
                #print(items)#[{'image_path': '/root/autodl-tmp/celeb_df/Celeb-real/id1_0007.mp4/0000.png', 'label': 1}, ...]
                
        return items

    def __getitem__(self, index):
        item = self.items[index]
        label = item['label']
        #print(item['image_path'])
        image = cv2.cvtColor(cv2.imread(item['image_path']), cv2.COLOR_BGR2RGB)
        image = self.transforms[self.split](image=image)['image']

        return image, label, image

    def __len__(self):
        return len(self.items)

    