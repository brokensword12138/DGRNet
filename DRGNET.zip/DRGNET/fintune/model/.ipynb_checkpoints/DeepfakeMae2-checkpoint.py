from timm.models.vision_transformer import VisionTransformer
from model.models_mae2 import mae_vit_base_patch16
import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F

from model.mscc import *
from functools import partial
from model.modules import *
from .modules import *
mae_weights = "/root/autodl-tmp/checkpoint02/model_best.pth.tar"



  
cfg = { 'patch_size': 16, 'embed_dim': 768, 'depth': 12, 'num_heads': 12, 
        'mlp_ratio': 4, 'qkv_bias': True, 'norm_layer': partial(nn.LayerNorm, eps=1e-6)}
vit_weights = '/root/autodl-tmp/vit_weight/jx_vit_base_p16_224-80ecf9dd.pth'

class BlockClassifier(VisionTransformer):
    def __init__(self, **kwargs):
        super(BlockClassifier, self).__init__(**kwargs)
        self.load_state_dict(torch.load(vit_weights))
    
    def forward(self, x):
        D = self.embed_dim
        B = x.shape[0]
        
        x = self.patch_embed(x)
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x = x + self.pos_embed
        x = self.pos_drop(x)

                
        for blk in self.blocks:
            x = blk(x)
        
        x = self.norm(x)
        
        return x[:, 0]

class ResidualGenerator(nn.Module):
    def __init__(self):
        super().__init__()
        mae = mae_vit_base_patch16().cuda()
        mae.load_state_dict(torch.load(mae_weights)["state_dict"], strict=True)
        self.inpainter = mae
        

    def forward(self, rgb_01, test=False):      
        with torch.no_grad():
            res = self.inpainter.patch_by_patch_DIFF(rgb_01)
        return res#, patch_id

class fuse_Segment(nn.Module):
    def __init__(self):
        super().__init__()
        mae = mae_vit_base_patch16().cuda()
        mae.load_state_dict(torch.load(mae_weights)["state_dict"], strict=True)
        self.locater = mae
        self.msff = MPFF(size=7)
        
    def forward(self, rgb_01, test=False):   
       
        loc = self.locater.segment_backbone(rgb_01)#将res传过来 res: torch.Size([32, 49, 768])                
        #将loc的尺寸改为32,768,7,7
        #print("改之前",loc.size())
        l0 = loc[0]
        l0 = l0.permute(0,2,1)
        B, C, HW = l0.size()
        l0 = l0.reshape(B,C,7,7)        
        
        l1 = loc[1]
        l1 = l1.permute(0,2,1)
        l1 = l1.reshape(B,C,7,7) 
        
        l2 = loc[2]
        l2 = l2.permute(0,2,1)
        l2 = l2.reshape(B,C,7,7) 
        
        l3 = loc[3]
        l3 = l3.permute(0,2,1)
        l3 = l3.reshape(B,C,7,7) 
        
        l4 = loc[4]
        l4 = l4.permute(0,2,1)
        l4 = l4.reshape(B,C,7,7) 
        
        l5 = loc[5] 
        l5 = l5.permute(0,2,1)
        l5 = l5.reshape(B,C,7,7)
        
        l4m = self.msff(l4, l5)
        l3m = self.msff(l3, l5)
        l2m = self.msff(l2, l5)
        l1m = self.msff(l1, l5)
        l0m = self.msff(l0, l5)
        seg_feas = torch.cat((l0m, l1m, l2m, l3m, l4m, l5), dim=1)
        #print("聚合特征",seg_feas.size())#[16, 773, 7, 7])
        #exit(0)
        #loc = loc.permute(0,2,1)
        #B, C, HW = loc.size()
        #loc = loc.reshape(B,C,7,7)                      
        #print("改之后",res.size())
        #exit(0)
        return seg_feas
        
class DeepfakeDetector(nn.Module):
    def __init__(self):
        super().__init__()
        
        self.backbone_1 = BlockClassifier(**cfg)
        self.backbone_2 = BlockClassifier(**cfg)
        self.classifier = nn.Linear(cfg['embed_dim'] * 2, 2)
    
    def forward(self, res, rgb_norm):

        feature_1 = self.backbone_1(rgb_norm)
        feature_2 = self.backbone_2(res)
        #print("rgb_norm:",rgb_norm.size())#rgb_norm: torch.Size([32, 3, 224, 224])
        #print("res:",res.size())#res: torch.Size([32, 3, 224, 224])
        #print("feature_1:",feature_1.size())#feature_1: torch.Size([32, 768])
        #print("feature_2:",feature_2.size())#feature_2: torch.Size([32, 768])
        feature = torch.cat([feature_1, feature_2], dim=1)
        #print("feature:",feature.size())#feature: torch.Size([32, 1536])
        
        output = self.classifier(feature)
        #print("output:",output.size())#output: torch.Size([32, 2])
        
        return feature, output

class RFFRL(nn.Module):

    def __init__(self):
        super().__init__()
        
        self.rg = ResidualGenerator()
        self.dd = DeepfakeDetector()
        self.fs = fuse_Segment()
        self.mscc = MSCC()
        self.lfga = LFGA(in_channel=773)
        self.conv = nn.Conv2d(3, 773, kernel_size=1)
        self.adapconv = nn.AdaptiveAvgPool2d((7,7))
        self.params = {
            'location': {
                'size': 7,
                'channels': [64, 128, 256, 728, 728, 728],
                'mid_channel': 512
            },
            'cls_size': 10,
            'HBFusion': {
                'hidden_dim': 2048,
                'output_dim': 4096,
            }
        }
        self.seg_header = nn.Sequential(
            nn.BatchNorm2d(773),
            nn.ReLU(inplace=True),
            nn.Conv2d(773, 2, kernel_size=1, bias=False),
        )
    def get_mask(self, mask):
        b, c, h, w = mask.size() 
        padding = abs(h % self.params['location']['size'] - self.params['location']['size']) % self.params['location']['size'] 
        pad = nn.ReplicationPad2d(padding=(padding // 2, (padding + 1) // 2, padding // 2, (padding + 1) // 2)).to(mask.device)
        max_pool = nn.MaxPool2d(kernel_size=h // self.params['location']['size'], stride=h // self.params['location']['size'], padding=0)

        return max_pool(mask)
       
    
    def forward(self, rgb_norm, mask):
        
        res = self.rg(rgb_norm)#torch.Size([32, 3, 224, 224])
        
        res_loc = self.conv(res)
        res_loc = self.adapconv(res_loc)#torch.Size([32, 768, 7, 7])这两步主要是将特征尺寸缩放到大小一致
    
        #print("res",res.size())
        #exit(0)
        feature, output = self.dd(res, rgb_norm)
        loc = self.fs(rgb_norm)#多层次聚合encoder输出#([16, 773, 7, 7])
        
        #print("loc",loc.size())
        #resloc, _ = self.mscc(loc)
        #print("resloc",resloc.size())#([32, 512, 7, 7])
        #exit(0)
        loc = self.lfga(loc,res_loc)#利用生成的残差图像对分割特征进行引导
        
        #print("loc",loc.size())#torch.Size([32, 768, 7, 7])
        #exit(0)
        segpreds = self.seg_header(loc)
        
        if mask is not None:
            if isinstance(mask, list):
                for i in range(len(mask)):
                    mask[i] = self.get_mask(mask[i])
                    mask[i][mask[i] > 0] = 1.0
            else:
                mask = self.get_mask(mask)
                mask[mask > 0] = 1.0
        
        #print("output:",output.size())
        #print("segpreds:",output.size())
        
        return  output, segpreds, mask
