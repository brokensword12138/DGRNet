from timm.models.vision_transformer import VisionTransformer
from model.models_mae import mae_vit_base_patch16
import torch
import torch.nn as nn
import numpy as np
import torch.nn.functional as F

from model.mscc import *
from functools import partial
from model.modules import *
from .modules import *
mae_weights = "/root/autodl-tmp/ckpt_c23pretrain/model_best.pth.tar"



  
cfg = { 'patch_size': 16, 'embed_dim': 768, 'depth': 12, 'num_heads': 12, 
        'mlp_ratio': 4, 'qkv_bias': True, 'norm_layer': partial(nn.LayerNorm, eps=1e-6)}
vit_weights = '/root/autodl-tmp/vit_weight/jx_vit_base_p16_224-80ecf9dd.pth'

class BlockClassifier(VisionTransformer):
    def __init__(self, **kwargs):
        super(BlockClassifier, self).__init__(**kwargs)
        self.load_state_dict(torch.load(vit_weights))
    
    def forward(self, x):
        D = self.embed_dim
        B = x.shape[0]
        
        x = self.patch_embed(x)
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x = x + self.pos_embed
        x = self.pos_drop(x)

                
        for blk in self.blocks:
            x = blk(x)
        
        x = self.norm(x)
        
        return x[:, 0]

class ResidualGenerator(nn.Module):
    def __init__(self):
        super().__init__()
        mae = mae_vit_base_patch16().cuda()
        mae.load_state_dict(torch.load(mae_weights)["state_dict"], strict=True)
        self.inpainter = mae
        

    def forward(self, rgb_01, test=False):      
        with torch.no_grad():
            res = self.inpainter.patch_by_patch_DIFF(rgb_01)
        return res#, patch_id

class Segment(nn.Module):
    def __init__(self):
        super().__init__()
        mae = mae_vit_base_patch16().cuda()
        mae.load_state_dict(torch.load(mae_weights)["state_dict"], strict=True)
        self.locater = mae
        
        
    def forward(self, rgb_01, test=False):   
       
        loc = self.locater.segment_backbone(rgb_01)#将res传过来 res: torch.Size([32, 49, 768])                
        #将loc的尺寸改为32,768,7,7
        #print("改之前",loc.size())
        loc = loc.permute(0,2,1)
        B, C, HW = loc.size()
        loc = loc.reshape(B,C,7,7)                      
        #print("改之后",res.size())
        #exit(0)
        return loc
        
class DeepfakeDetector(nn.Module):
    def __init__(self):
        super().__init__()
        
        self.backbone_1 = BlockClassifier(**cfg)
        self.backbone_2 = BlockClassifier(**cfg)
        self.classifier = nn.Linear(cfg['embed_dim'] * 2, 2)
    
    def forward(self, res, rgb_norm):

        feature_1 = self.backbone_1(rgb_norm)
        feature_2 = self.backbone_2(res)
        #print("rgb_norm:",rgb_norm.size())#rgb_norm: torch.Size([32, 3, 224, 224])
        #print("res:",res.size())#res: torch.Size([32, 3, 224, 224])
        #print("feature_1:",feature_1.size())#feature_1: torch.Size([32, 768])
        #print("feature_2:",feature_2.size())#feature_2: torch.Size([32, 768])
        feature = torch.cat([feature_1, feature_2], dim=1)
        #print("feature:",feature.size())#feature: torch.Size([32, 1536])
        
        output = self.classifier(feature)
        #print("output:",output.size())#output: torch.Size([32, 2])
        
        return feature, output

def visualize_res_loc(loc):
    # 可视化 res
    save_dir_res = '/root/autodl-tmp/image_outputs/loc'
    os.makedirs(save_dir_res, exist_ok=True)
    for i in range(res.shape[0]):
        
        imager = torch.permute(res[0], (1, 2, 0))
        imager = imager.detach().cpu().numpy()
    
        # 创建子图
        fig, ax = plt.subplots(figsize=(5, 5))
    
        # 显示图像
        ax.imshow(imager, cmap='gray')
        ax.axis('off')
    
        file_path = os.path.join(save_dir_res,f'image_{i}.png')
        plt.savefig(file_path)
        plt.close(fig)
        
        
class RFFRL(nn.Module):

    def __init__(self):
        super().__init__()
        
        self.rg = ResidualGenerator()
        self.dd = DeepfakeDetector()
        self.ls = Segment()
        self.mscc = MSCC()
        self.lfga = LFGA(in_channel=768)
        self.conv = nn.Conv2d(3, 768, kernel_size=1)
        self.adapconv = nn.AdaptiveAvgPool2d((7,7))
        self.params = {
            'location': {
                'size': 7,
                'channels': [64, 128, 256, 728, 728, 728],
                'mid_channel': 512
            },
            'cls_size': 10,
            'HBFusion': {
                'hidden_dim': 2048,
                'output_dim': 4096,
            }
        }
        self.seg_header = nn.Sequential(
            nn.BatchNorm2d(768),
            nn.ReLU(inplace=True),
            nn.Conv2d(768, 2, kernel_size=1, bias=False),
        )
    def get_mask(self, mask):
        b, c, h, w = mask.size() 
        padding = abs(h % self.params['location']['size'] - self.params['location']['size']) % self.params['location']['size'] 
        pad = nn.ReplicationPad2d(padding=(padding // 2, (padding + 1) // 2, padding // 2, (padding + 1) // 2)).to(mask.device)
        max_pool = nn.MaxPool2d(kernel_size=h // self.params['location']['size'], stride=h // self.params['location']['size'], padding=0)

        return max_pool(mask)
       
    
    def forward(self, rgb_norm, mask):
        
        res = self.rg(rgb_norm)#torch.Size([32, 3, 224, 224])
        res_loc = self.conv(res)
        res_loc = self.adapconv(res_loc)#torch.Size([32, 768, 7, 7])
    
        #print("res",res.size())
        #exit(0)
        feature, output = self.dd(res, rgb_norm)
        loc = self.ls(rgb_norm)
        #print("loc",loc.size())#([32, 768, 7, 7])
        #resloc, _ = self.mscc(loc)
        #print("resloc",resloc.size())#([32, 512, 7, 7])
        #exit(0)
        loc = self.lfga(loc,res_loc)
        #print("loc",loc.size())#torch.Size([32, 768, 7, 7])
        #exit(0)
        
        #segpreds = self.seg_header(loc)
        
        #visualize_res_loc(inputs)
        
        loc = F.interpolate(loc, size=(14, 14), mode="bilinear", align_corners=True)
        loc = F.interpolate(loc, size=(28, 28), mode="bilinear", align_corners=True)
        loc = F.interpolate(loc, size=(56, 56), mode="bilinear", align_corners=True)
        loc = F.interpolate(loc, size=(112, 112), mode="bilinear", align_corners=True)
        loc = F.interpolate(loc, size=(224, 224), mode="bilinear", align_corners=True)
        #48,768,224,224
        
        segpreds = self.seg_header(loc)
        
        print("segpreds",segpreds.size())
        #segpreds torch.Size([48, 2, 224, 224])
        
        
        if mask is not None:
            if isinstance(mask, list):
                for i in range(len(mask)):
                    mask[i] = self.get_mask(mask[i])
                    mask[i][mask[i] > 0] = 1.0
            else:
                mask = self.get_mask(mask)
                mask[mask > 0] = 1.0
        
        #print("output:",output.size())
        #print("segpreds:",output.size())
        
        return  output, segpreds, mask
